#ifndef MY_MATH_H
#define MY_MATH_H
using namespace std;

double divide(double a, double b);
double findMax(double a, double b);
double findMin(double a, double b);
int factorial(int n);

#endif




